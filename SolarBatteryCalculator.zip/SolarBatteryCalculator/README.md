# Solar Battery Calculator

Native Android app (Kotlin, Jetpack Compose).

Each plant is a card you swipe through. A plant has a name and address (up to a few
lines), a factory capacity, an optional current capacity, and a reserve percentage. If
current capacity is filled in, it is used instead of the factory capacity. Each plant
also keeps its own charge level and power draw.

The Calculator tab shows hours left and the date and time the battery runs out. The
Breakdown tab shows the same plant card, a chart, and an hourly list.

The clock follows the real time. Tap the time to set another one with Android's standard
clock dial (or type it with the keyboard button). Tap Now or Back to now to return to the
real time. The gauge size adjusts to the height of the screen.

## Build with GitHub

Keep `SolarBatteryCalculator.zip` and `.github/workflows/build-apk.yml` in the repo.
Pushing to `main` runs the unit tests, builds a signed APK and publishes it under Releases.

Every build is signed with the same key, kept in four repository secrets (KEYSTORE_BASE64,
KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD), and each build gets a higher version number
than the last. That is what lets a new APK install as an update over the old one. Keep a
backup of the keystore file: if it is lost, updates are no longer possible.

## Layout

- `Plant.kt`, `Calculator.kt` the plant model and all the maths and wording
- `CalculatorViewModel.kt` app state, `PlantStore.kt` saved plants
- `ui/` the Compose theme and screens
- `app/src/test/` unit tests for the calculator
