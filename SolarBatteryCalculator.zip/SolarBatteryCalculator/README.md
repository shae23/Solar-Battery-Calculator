# Solar Battery Calculator

Native Android app (Kotlin, Jetpack Compose).

Each plant is a card you swipe through. A plant has a name and address (up to a few
lines), a factory capacity, an optional current capacity, and a reserve percentage. If
current capacity is filled in, it is used instead of the factory capacity. Each plant
also keeps its own charge level and power draw.

The Calculator tab shows hours left and the date and time the battery runs out. The
Breakdown tab shows the same plant card, a chart, and an hourly list.

## Build with GitHub

Keep `SolarBatteryCalculator.zip` and `.github/workflows/build-apk.yml` in the repo.
Pushing to `main` runs the unit tests, builds a debug APK and publishes it under Releases.

## Layout

- `Plant.kt`, `Calculator.kt` the plant model and all the maths and wording
- `CalculatorViewModel.kt` app state, `PlantStore.kt` saved plants
- `ui/` the Compose theme and screens
- `app/src/test/` unit tests for the calculator
