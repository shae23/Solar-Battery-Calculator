# Solar Battery Calculator

Native Android app (Kotlin, Jetpack Compose). Enter battery capacity, reserve and
current charge, then a load, and it shows usable energy, runway, the time it runs
out, and an hourly breakdown. Saved plants (capacity and reserve) persist on the device.

## Build with GitHub

Push this folder to a GitHub repo on the `main` branch. The Build APK workflow runs
the unit tests and builds a debug APK. Open the run under the Actions tab and download
`solar-battery-calculator-debug` from the Artifacts section. Unzip it and install
`app-debug.apk` on the phone (allow installs from unknown sources).

## Layout

- `app/src/main/java/com/solarbatterycalc/Calculator.kt` all the maths and text formatting
- `CalculatorViewModel.kt` screen state and saved plant actions
- `PlantStore.kt` saved plants in SharedPreferences
- `ui/` Compose theme and screen
- `app/src/test/` unit tests for the calculator

## Local build

Open the folder in Android Studio, or run `gradle assembleDebug` with Gradle 8.9 and JDK 17.
