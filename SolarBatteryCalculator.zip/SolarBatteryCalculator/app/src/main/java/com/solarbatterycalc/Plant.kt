package com.solarbatterycalc

enum class PowerUnit { W, KW }

data class Plant(
    val id: String,
    val name: String = "",
    val factory: String = "",
    val current: String = "",
    val reserve: String = "",
    val charge: Int = 100,
    val load: String = "",
    val unit: PowerUnit = PowerUnit.W,
) {
    val effectiveCapacity: String
        get() = if (current.isNotEmpty()) current else factory

    private val lines: List<String>
        get() = name.lines().map { it.trim() }.filter { it.isNotEmpty() }

    val title: String
        get() = lines.firstOrNull() ?: "Unnamed"

    val detail: String
        get() = lines.drop(1).joinToString("\n")

    val detailInline: String
        get() = lines.drop(1).joinToString(", ")

    val capacityLabel: String
        get() {
            val cap = when {
                current.isNotEmpty() && factory.isNotEmpty() -> "$current of $factory"
                current.isNotEmpty() -> current
                factory.isNotEmpty() -> factory
                else -> "--"
            }
            return "$cap kWh, ${reserve.ifEmpty { "--" }}% reserve"
        }
}
