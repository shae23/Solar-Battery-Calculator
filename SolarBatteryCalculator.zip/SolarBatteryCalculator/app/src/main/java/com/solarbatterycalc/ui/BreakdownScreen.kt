package com.solarbatterycalc.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarbatterycalc.CalcResult
import com.solarbatterycalc.Calculator
import com.solarbatterycalc.CalculatorViewModel
import com.solarbatterycalc.HourlyRow
import com.solarbatterycalc.Plant
import java.time.LocalDateTime

@Composable
fun BreakdownScreen(vm: CalculatorViewModel, start: LocalDateTime, modifier: Modifier = Modifier) {
    val active = vm.active
    Column(
        modifier
            .fillMaxSize()
            .padding(top = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (active == null) {
            CenterMessage("Add a plant on the Calculator tab to see its breakdown.")
            return@Column
        }

        PlantPager(vm, userScroll = true) { _, plant ->
            MiniCard(plant, Calculator.compute(plant, start))
        }
        DotsRow(vm, showAdd = false)

        val result = Calculator.compute(active, start)
        if (result.rows.isEmpty()) {
            CenterMessage(
                when {
                    !result.hasCapacity -> "Set capacity and reserve on the Calculator tab first."
                    result.message.isNotEmpty() -> "Enter a load on the Calculator tab to see the hourly breakdown."
                    else -> "Nothing is left above the reserve level."
                },
            )
        } else {
            ChartCard(result.rows)
            LazyColumn(
                Modifier
                    .weight(1f)
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(bottom = 12.dp),
            ) {
                items(result.rows) { row -> HourRow(row) }
            }
        }
    }
}

@Composable
private fun CenterMessage(text: String) {
    Text(
        text,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 36.dp, vertical = 40.dp),
        color = LocalSolarColors.current.muted,
        fontSize = 15.sp,
        textAlign = TextAlign.Center,
    )
}

@Composable
private fun MiniCard(plant: Plant, result: CalcResult) {
    val c = LocalSolarColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 96.dp)
            .surface(RoundedCornerShape(20.dp), c.card, c.border)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                plant.title,
                color = c.text,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (plant.detailInline.isNotEmpty()) {
                Text(
                    plant.detailInline,
                    color = c.muted,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                "${plant.charge}% charge",
                color = c.muted,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(result.hours, color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            val runsOut = result.runsOut
            if (runsOut != null) {
                Text("Runs out", color = c.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(runsOut, color = c.accentStrong, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun ChartCard(rows: List<HourlyRow>) {
    val c = LocalSolarColors.current
    Column(
        Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth()
            .surface(RoundedCornerShape(20.dp), c.card, c.border)
            .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 12.dp),
    ) {
        Text(
            "Charge left, hour by hour",
            color = c.muted,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 10.dp),
        )
        Row(
            Modifier
                .fillMaxWidth()
                .height(120.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            rows.forEach { row ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight(row.fraction.coerceIn(0.03f, 1f))
                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                        .background(c.accent),
                )
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(c.border),
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(rows.first().label, color = c.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(rows.last().label, color = c.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun HourRow(row: HourlyRow) {
    val c = LocalSolarColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .surface(RoundedCornerShape(14.dp), c.card, c.border)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            row.label,
            modifier = Modifier.width(112.dp),
            color = c.text,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
        )
        Box(
            Modifier
                .weight(1f)
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(c.track),
        ) {
            Box(
                Modifier
                    .fillMaxWidth(row.fraction.coerceIn(0f, 1f))
                    .fillMaxHeight()
                    .background(c.accent),
            )
        }
        Text(
            row.percent,
            modifier = Modifier.width(36.dp),
            color = c.accentStrong,
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.End,
        )
        Text(
            row.kwh,
            modifier = Modifier.width(64.dp),
            color = c.muted,
            fontSize = 12.sp,
            textAlign = TextAlign.End,
        )
    }
}
