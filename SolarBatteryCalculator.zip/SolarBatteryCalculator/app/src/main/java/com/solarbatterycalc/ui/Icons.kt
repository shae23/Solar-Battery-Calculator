package com.solarbatterycalc.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

object SolarIcons {
    val Bolt = build("Bolt") {
        line(2f) {
            moveTo(13f, 3f)
            lineTo(5f, 14f)
            horizontalLineToRelative(6f)
            lineToRelative(-1f, 7f)
            lineToRelative(8f, -11f)
            horizontalLineToRelative(-6f)
            close()
        }
    }

    val Bars = build("Bars") {
        line(2f) {
            moveTo(5f, 20f)
            verticalLineToRelative(-8f)
        }
        line(2f) {
            moveTo(12f, 20f)
            verticalLineTo(5f)
        }
        line(2f) {
            moveTo(19f, 20f)
            verticalLineToRelative(-9f)
        }
    }

    val Pencil = build("Pencil") {
        line(2f) {
            moveTo(4f, 20f)
            lineToRelative(4f, -1f)
            lineToRelative(11f, -11f)
            lineToRelative(-3f, -3f)
            lineTo(5f, 16f)
            close()
        }
    }

    val Plus = build("Plus") {
        line(2.4f) {
            moveTo(12f, 5f)
            verticalLineToRelative(14f)
            moveTo(5f, 12f)
            horizontalLineToRelative(14f)
        }
    }

    val Minus = build("Minus") {
        line(2.4f) {
            moveTo(5f, 12f)
            horizontalLineToRelative(14f)
        }
    }

    val Keyboard = build("Keyboard") {
        line(2f) {
            moveTo(3f, 6f)
            lineTo(21f, 6f)
            lineTo(21f, 18f)
            lineTo(3f, 18f)
            close()
        }
        line(2f) {
            moveTo(7f, 10f)
            horizontalLineToRelative(0.01f)
            moveTo(11f, 10f)
            horizontalLineToRelative(0.01f)
            moveTo(15f, 10f)
            horizontalLineToRelative(0.01f)
            moveTo(7f, 14f)
            horizontalLineToRelative(10f)
        }
    }

    val Clock = build("Clock") {
        line(2f) {
            moveTo(12f, 3f)
            arcToRelative(9f, 9f, 0f, true, true, 0f, 18f)
            arcToRelative(9f, 9f, 0f, true, true, 0f, -18f)
            close()
        }
        line(2f) {
            moveTo(12f, 7f)
            verticalLineToRelative(5f)
            lineToRelative(3f, 2f)
        }
    }

    val Check = build("Check") {
        line(2.4f) {
            moveTo(5f, 12f)
            lineToRelative(5f, 5f)
            lineToRelative(9f, -10f)
        }
    }
}

private fun build(name: String, block: ImageVector.Builder.() -> Unit): ImageVector =
    ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
    ).apply(block).build()

private fun ImageVector.Builder.line(width: Float, draw: PathBuilder.() -> Unit) {
    path(
        stroke = SolidColor(Color.Black),
        strokeLineWidth = width,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
        pathBuilder = draw,
    )
}
