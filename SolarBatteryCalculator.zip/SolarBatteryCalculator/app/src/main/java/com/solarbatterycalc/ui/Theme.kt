package com.solarbatterycalc.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class SolarColors(
    val bg: Color,
    val card: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val accentStrong: Color,
    val onAccentStrong: Color,
    val accentSoft: Color,
    val border: Color,
    val inputBorder: Color,
    val track: Color,
    val dot: Color,
    val warn: Color,
    val onWarn: Color,
)

private val LightColors = SolarColors(
    bg = Color(0xFFF6F3EE),
    card = Color(0xFFFFFFFF),
    text = Color(0xFF1E1C19),
    muted = Color(0xFF5F5A52),
    accent = Color(0xFFD97F22),
    accentStrong = Color(0xFFA9570B),
    onAccentStrong = Color(0xFFFFFFFF),
    accentSoft = Color(0xFFFCEAD6),
    border = Color(0xFFE4DED4),
    inputBorder = Color(0xFF8F887B),
    track = Color(0xFFE4DED4),
    dot = Color(0xFFCFC8BB),
    warn = Color(0xFFB3541E),
    onWarn = Color(0xFFFFFFFF),
)

private val DarkColors = SolarColors(
    bg = Color(0xFF17181A),
    card = Color(0xFF202225),
    text = Color(0xFFECECEA),
    muted = Color(0xFFA5A7A2),
    accent = Color(0xFFE59A49),
    accentStrong = Color(0xFFE59A49),
    onAccentStrong = Color(0xFF1C1E1B),
    accentSoft = Color(0xFF3A2C1C),
    border = Color(0xFF33352F),
    inputBorder = Color(0xFF7C7F78),
    track = Color(0xFF33352F),
    dot = Color(0xFF4A4C48),
    warn = Color(0xFFE08A4D),
    onWarn = Color(0xFF1C1E1B),
)

val LocalSolarColors = staticCompositionLocalOf { LightColors }

@Composable
fun SolarTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val c = if (dark) DarkColors else LightColors
    val scheme = if (dark) {
        darkColorScheme(primary = c.accent, background = c.bg, surface = c.card, onSurface = c.text)
    } else {
        lightColorScheme(primary = c.accent, background = c.bg, surface = c.card, onSurface = c.text)
    }
    CompositionLocalProvider(LocalSolarColors provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
