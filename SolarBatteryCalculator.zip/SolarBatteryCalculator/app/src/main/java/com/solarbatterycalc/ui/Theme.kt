package com.solarbatterycalc.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
data class SolarColors(
    val bg: Color,
    val card: Color,
    val text: Color,
    val muted: Color,
    val accent: Color,
    val accentSoft: Color,
    val border: Color,
    val good: Color,
    val warn: Color,
)

private val LightColors = SolarColors(
    bg = Color(0xFFF5F6F4),
    card = Color(0xFFFFFFFF),
    text = Color(0xFF1C1E1B),
    muted = Color(0xFF6B6F68),
    accent = Color(0xFFD97F22),
    accentSoft = Color(0xFFFCEAD6),
    border = Color(0xFFE2E4DE),
    good = Color(0xFF2E7D4F),
    warn = Color(0xFFB3541E),
)

private val DarkColors = SolarColors(
    bg = Color(0xFF17181A),
    card = Color(0xFF202225),
    text = Color(0xFFECECEA),
    muted = Color(0xFF9A9C98),
    accent = Color(0xFFE59A49),
    accentSoft = Color(0xFF3A2C1C),
    border = Color(0xFF33352F),
    good = Color(0xFF5FBF85),
    warn = Color(0xFFE08A4D),
)

val LocalSolarColors = staticCompositionLocalOf { LightColors }

@Composable
fun SolarTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val c = if (dark) DarkColors else LightColors
    val scheme = if (dark) {
        darkColorScheme(primary = c.accent, background = c.bg, surface = c.card, onSurface = c.text)
    } else {
        lightColorScheme(primary = c.accent, background = c.bg, surface = c.card, onSurface = c.text)
    }
    CompositionLocalProvider(LocalSolarColors provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
