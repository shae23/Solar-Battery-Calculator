package com.solarbatterycalc.ui

import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.solarbatterycalc.CalculatorViewModel
import java.time.LocalDateTime
import kotlinx.coroutines.delay

@Composable
fun SolarApp(vm: CalculatorViewModel) {
    val c = LocalSolarColors.current
    var tab by rememberSaveable { mutableStateOf(0) }

    val now by produceState(initialValue = LocalDateTime.now()) {
        while (true) {
            delay(15_000)
            value = LocalDateTime.now()
        }
    }
    val start = now.plusMinutes(vm.timeOffsetMin.toLong())

    val itemColors = NavigationBarItemDefaults.colors(
        selectedIconColor = c.text,
        selectedTextColor = c.text,
        unselectedIconColor = c.muted,
        unselectedTextColor = c.muted,
        indicatorColor = c.accentSoft,
    )

    Scaffold(
        containerColor = c.bg,
        bottomBar = {
            NavigationBar(containerColor = c.card) {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(SolarIcons.Bolt, contentDescription = null) },
                    label = { Text("Calculator") },
                    colors = itemColors,
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = {
                        vm.stopEditing()
                        tab = 1
                    },
                    icon = { Icon(SolarIcons.Bars, contentDescription = null) },
                    label = { Text("Breakdown") },
                    colors = itemColors,
                )
            }
        },
    ) { inner ->
        val body = Modifier
            .padding(inner)
            .consumeWindowInsets(inner)
            .imePadding()
        if (tab == 0) {
            CalculatorScreen(vm, start, body)
        } else {
            BreakdownScreen(vm, start, body)
        }
    }
}
