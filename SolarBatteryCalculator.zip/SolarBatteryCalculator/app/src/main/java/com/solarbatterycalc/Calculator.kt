package com.solarbatterycalc

import java.util.Locale
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

enum class PowerUnit { W, KW }

data class Inputs(
    val capacity: String,
    val reservePct: String,
    val currentPct: String,
    val load: String,
    val unit: PowerUnit,
    val startHour: String,
    val startMinute: String,
    val isPm: Boolean,
)

data class HourlyRow(val timeLabel: String, val percent: String, val kwh: String)

sealed interface Hourly {
    data class Message(val text: String) : Hourly
    data class Rows(val rows: List<HourlyRow>) : Hourly
}

const val NO_KWH = "-- kWh"
const val NO_HOURS = "-- h"
const val HOURLY_HINT = "Fill in capacity, charge, and load to see the hourly breakdown."

data class CalcResult(
    val usable: String = NO_KWH,
    val reserve: String = NO_KWH,
    val currentUsable: String = NO_KWH,
    val hours: String = NO_HOURS,
    val etaText: String = "",
    val etaTime: String? = null,
    val barFraction: Float = 0f,
    val flag: String = "",
    val hourly: Hourly = Hourly.Message(HOURLY_HINT),
)

object Calculator {
    private const val MAX_HOURLY_STEPS = 48

    fun compute(i: Inputs): CalcResult {
        if (i.capacity.isEmpty() || i.reservePct.isEmpty()) {
            return CalcResult(etaText = "Enter capacity and reserve to get started")
        }

        val capacity = max(0.0, i.capacity.toDoubleOrNull() ?: 0.0)
        val reservePct = (i.reservePct.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 100.0)

        val reserveKwh = capacity * (reservePct / 100)
        val usableKwh = capacity - reserveKwh

        val base = CalcResult(usable = fmtKwh(usableKwh), reserve = fmtKwh(reserveKwh))

        if (i.currentPct.isEmpty()) {
            return base.copy(etaText = "Enter your current charge to see runway")
        }

        val currentPct = (i.currentPct.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 100.0)
        val currentTotalKwh = capacity * (currentPct / 100)
        val currentUsableKwh = max(0.0, currentTotalKwh - reserveKwh)
        val withCurrent = base.copy(currentUsable = fmtKwh(currentUsableKwh))

        val loadRaw = i.load.toDoubleOrNull()
        val loadKw = loadRaw?.let { if (i.unit == PowerUnit.W) it / 1000 else it }
        if (loadKw == null || !loadKw.isFinite() || loadKw <= 0) {
            return withCurrent.copy(etaText = "Enter a load above zero")
        }

        val hoursRemaining = currentUsableKwh / loadKw
        val fraction = if (usableKwh > 0) (currentUsableKwh / usableKwh).coerceIn(0.0, 1.0) else 0.0

        val h12 = i.startHour.toIntOrNull()
        val minute = i.startMinute.toIntOrNull() ?: 0
        val eta = addHoursToTime(h12, minute, i.isPm, hoursRemaining)

        val flag = when {
            currentUsableKwh <= 0 -> "Currently usable is zero, at or below reserve level."
            hoursRemaining < 1 -> "Under an hour left at this rate."
            else -> ""
        }

        val result = withCurrent.copy(
            hours = fmtHours(hoursRemaining),
            barFraction = fraction.toFloat(),
            flag = flag,
        )

        val withEta = if (eta != null) {
            val dayNote = when {
                eta.daysAhead == 1 -> " (next day)"
                eta.daysAhead > 1 -> " (+${eta.daysAhead} days)"
                else -> ""
            }
            result.copy(etaText = "Runs out around ", etaTime = eta.time + dayNote)
        } else {
            result.copy(etaText = "Set a time to see when it runs out")
        }

        if (currentUsableKwh <= 0 || usableKwh <= 0) return withEta

        return withEta.copy(
            hourly = buildHourly(currentUsableKwh, usableKwh, loadKw, h12, minute, i.isPm),
        )
    }

    private fun buildHourly(
        currentUsableKwh: Double,
        usableKwh: Double,
        loadKw: Double,
        h12: Int?,
        minute: Int,
        isPm: Boolean,
    ): Hourly {
        val totalHours = currentUsableKwh / loadKw
        val steps = min(MAX_HOURLY_STEPS, ceil(totalHours).toInt())
        val rows = ArrayList<HourlyRow>()
        for (n in 1..steps) {
            val hoursIn = min(n.toDouble(), totalHours)
            val remaining = max(0.0, currentUsableKwh - loadKw * hoursIn)
            val pct = (remaining / usableKwh * 100).coerceIn(0.0, 100.0)
            val eta = addHoursToTime(h12, minute, isPm, hoursIn)
            val label = if (eta == null) {
                "--"
            } else {
                eta.time + if (eta.daysAhead >= 1) " (+${eta.daysAhead}d)" else ""
            }
            rows += HourlyRow(label, String.format(Locale.US, "%.0f%%", pct), fmtKwh(remaining))
            if (remaining <= 0) break
        }
        return if (rows.isEmpty()) Hourly.Message("Nothing to show yet.") else Hourly.Rows(rows)
    }

    internal fun fmtKwh(n: Double): String =
        if (n.isFinite()) String.format(Locale.US, "%.2f", n) + " kWh" else NO_KWH

    internal fun fmtHours(h: Double): String {
        if (!h.isFinite()) return NO_HOURS
        if (h <= 0) return "0 h 0 m"
        val totalMin = floor(h * 60 + 0.5).toLong()
        return "${totalMin / 60} h ${totalMin % 60} m"
    }

    internal data class Eta(val time: String, val daysAhead: Int)

    internal fun addHoursToTime(hour12: Int?, minute: Int, isPm: Boolean, hoursToAdd: Double): Eta? {
        if (hour12 == null || !hoursToAdd.isFinite()) return null
        val h24 = hour12 % 12 + if (isPm) 12 else 0
        val total = floor(h24 * 60 + minute + hoursToAdd * 60 + 1e-9).toLong()
        val days = (total / 1440).toInt()
        val rem = (total % 1440).toInt()
        return Eta(to12HourString(rem / 60, rem % 60), days)
    }

    private fun to12HourString(h24: Int, minute: Int): String {
        val period = if (h24 >= 12) "PM" else "AM"
        var h12 = h24 % 12
        if (h12 == 0) h12 = 12
        return String.format(Locale.US, "%d:%02d %s", h12, minute, period)
    }
}
