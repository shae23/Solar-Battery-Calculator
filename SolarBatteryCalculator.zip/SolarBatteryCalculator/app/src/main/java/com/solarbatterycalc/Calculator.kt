package com.solarbatterycalc

import java.time.LocalDateTime
import java.time.temporal.ChronoUnit
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

const val NO_KWH = "-- kWh"
const val NO_HOURS = "-- h"
const val MSG_NEEDS_CAPACITY = "Tap the pencil to set capacity and reserve"
const val MSG_NEEDS_LOAD = "Enter a load to see how long it lasts"

data class HourlyRow(
    val label: String,
    val percent: String,
    val kwh: String,
    val fraction: Float,
)

data class CalcResult(
    val hasCapacity: Boolean,
    val usable: String,
    val reserve: String,
    val available: String,
    val hours: String,
    val runsOut: String?,
    val message: String,
    val flag: String,
    val fraction: Float,
    val rows: List<HourlyRow>,
)

object Calculator {
    private const val MAX_HOURLY_STEPS = 24
    private val MONTHS = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

    fun compute(plant: Plant, start: LocalDateTime): CalcResult {
        val capText = plant.effectiveCapacity
        val hasCap = capText.isNotEmpty() && plant.reserve.isNotEmpty()
        val cap = max(0.0, capText.toDoubleOrNull() ?: 0.0)
        val reservePct = (plant.reserve.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 100.0)

        val reserveKwh = cap * (reservePct / 100)
        val usableKwh = cap - reserveKwh
        val availableKwh = max(0.0, cap * (plant.charge / 100.0) - reserveKwh)
        val fraction = if (hasCap && usableKwh > 0) (availableKwh / usableKwh).coerceIn(0.0, 1.0).toFloat() else 0f

        fun kwh(n: Double) = if (hasCap) fmtKwh(n) else NO_KWH

        val loadRaw = plant.load.toDoubleOrNull()
        val loadKw = loadRaw?.let { if (plant.unit == PowerUnit.W) it / 1000 else it }

        if (!hasCap || loadKw == null || !loadKw.isFinite() || loadKw <= 0) {
            return CalcResult(
                hasCapacity = hasCap,
                usable = kwh(usableKwh),
                reserve = kwh(reserveKwh),
                available = kwh(availableKwh),
                hours = NO_HOURS,
                runsOut = null,
                message = if (hasCap) MSG_NEEDS_LOAD else MSG_NEEDS_CAPACITY,
                flag = "",
                fraction = fraction,
                rows = emptyList(),
            )
        }

        val hours = availableKwh / loadKw
        val startMinute = start.truncatedTo(ChronoUnit.MINUTES)
        val runsOut = stamp(startMinute.plusMinutes(wholeMinutes(hours)), withDate = true)

        val flag = when {
            availableKwh <= 0 -> "At or below reserve level"
            hours < 1 -> "Under an hour left at this rate"
            else -> ""
        }

        val rows = if (availableKwh > 0 && usableKwh > 0) {
            buildRows(availableKwh, usableKwh, loadKw, hours, startMinute)
        } else {
            emptyList()
        }

        return CalcResult(
            hasCapacity = true,
            usable = kwh(usableKwh),
            reserve = kwh(reserveKwh),
            available = kwh(availableKwh),
            hours = fmtHours(hours),
            runsOut = runsOut,
            message = "",
            flag = flag,
            fraction = fraction,
            rows = rows,
        )
    }

    private fun buildRows(
        availableKwh: Double,
        usableKwh: Double,
        loadKw: Double,
        hours: Double,
        start: LocalDateTime,
    ): List<HourlyRow> {
        val rows = ArrayList<HourlyRow>()
        val nowFraction = min(1.0, availableKwh / usableKwh)
        rows += HourlyRow("Now", pct(nowFraction * 100), fmtKwh(availableKwh), nowFraction.toFloat())

        val steps = min(MAX_HOURLY_STEPS, ceil(hours).toInt())
        for (n in 1..steps) {
            val hoursIn = min(n.toDouble(), hours)
            val remaining = max(0.0, availableKwh - loadKw * hoursIn)
            val fraction = (remaining / usableKwh).coerceIn(0.0, 1.0)
            val at = start.plusMinutes(wholeMinutes(hoursIn))
            val label = stamp(at, withDate = at.toLocalDate() != start.toLocalDate())
            rows += HourlyRow(label, pct(fraction * 100), fmtKwh(remaining), fraction.toFloat())
            if (remaining <= 0) break
        }
        return rows
    }

    private fun wholeMinutes(hours: Double): Long =
        min(floor(hours * 60 + 1e-9), 1_000_000_000.0).toLong()

    private fun pct(p: Double): String = String.format(Locale.US, "%.0f%%", p)

    fun stamp(t: LocalDateTime, withDate: Boolean): String {
        val h24 = t.hour
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        val time = String.format(Locale.US, "%d:%02d %s", h12, t.minute, if (h24 >= 12) "PM" else "AM")
        return if (withDate) "${MONTHS[t.monthValue - 1]} ${t.dayOfMonth}, $time" else time
    }

    internal fun fmtKwh(n: Double): String =
        if (n.isFinite()) String.format(Locale.US, "%.2f", n) + " kWh" else NO_KWH

    internal fun fmtHours(h: Double): String {
        if (!h.isFinite()) return NO_HOURS
        if (h <= 0) return "0 h 0 m"
        val totalMin = floor(h * 60 + 0.5).toLong()
        return "${totalMin / 60} h ${totalMin % 60} m"
    }
}
