package com.solarbatterycalc.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.BorderStroke
import com.solarbatterycalc.CalcResult
import com.solarbatterycalc.Calculator
import com.solarbatterycalc.CalculatorViewModel
import com.solarbatterycalc.Plant
import com.solarbatterycalc.PowerUnit
import java.time.LocalDateTime
import kotlin.math.roundToInt

@Composable
fun CalculatorScreen(vm: CalculatorViewModel, start: LocalDateTime, modifier: Modifier = Modifier) {
    val active = vm.active
    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (active == null) {
            EmptyPlants(onAdd = vm::addPlant)
            return@Column
        }

        PlantPager(vm, userScroll = !vm.editing) { _, plant ->
            PlantCard(plant, Calculator.compute(plant, start), vm)
        }
        DotsRow(vm, showAdd = true)

        if (!vm.editing) {
            Controls(active, Calculator.compute(active, start), start, vm)
        }
    }
}

@Composable
private fun EmptyPlants(onAdd: () -> Unit) {
    val c = LocalSolarColors.current
    Column(
        Modifier
            .padding(horizontal = 20.dp)
            .fillMaxWidth()
            .surface(CardShape, c.card, c.border)
            .padding(horizontal = 24.dp, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("No plants yet", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        Text(
            "Add a plant to work out how long its battery will last.",
            color = c.muted,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
        Button(
            onClick = onAdd,
            colors = ButtonDefaults.buttonColors(containerColor = c.accentStrong, contentColor = c.onAccentStrong),
            modifier = Modifier.height(48.dp),
        ) {
            Text("Add a plant", fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun PlantCard(plant: Plant, result: CalcResult, vm: CalculatorViewModel) {
    val c = LocalSolarColors.current
    val editing = vm.editing && plant.id == vm.activeId
    Column(
        Modifier
            .fillMaxWidth()
            .surface(CardShape, c.card, c.border)
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        if (editing) {
            EditForm(plant, vm)
        } else {
            Summary(plant, result, onEdit = { vm.toggleEdit(plant.id) })
        }
    }
}

@Composable
private fun Summary(plant: Plant, result: CalcResult, onEdit: () -> Unit) {
    val c = LocalSolarColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 96.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                plant.title,
                color = c.text,
                fontSize = 17.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (plant.detail.isNotEmpty()) {
                Text(plant.detail, color = c.muted, fontSize = 13.sp)
            }
            Text(
                plant.capacityLabel,
                color = c.muted,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .padding(top = 6.dp)
                    .surface(RoundedCornerShape(10.dp), c.bg, c.bg)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
        RoundIconButton(SolarIcons.Pencil, "Edit plant", onEdit)
    }

    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Gauge(result, plant.charge)

        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 38.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            val runsOut = result.runsOut
            if (runsOut != null) {
                Text(
                    buildAnnotatedString {
                        append("Runs out ")
                        withStyle(SpanStyle(color = c.accentStrong, fontWeight = FontWeight.ExtraBold)) {
                            append(runsOut)
                        }
                    },
                    color = c.text,
                    fontSize = 15.sp,
                )
            } else {
                Text(result.message, color = c.muted, fontSize = 14.sp, textAlign = TextAlign.Center)
            }
            if (result.flag.isNotEmpty()) {
                Text(
                    result.flag,
                    color = c.warn,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 3.dp),
                )
            }
        }
    }
}

@Composable
private fun Gauge(result: CalcResult, charge: Int) {
    val c = LocalSolarColors.current
    val track = c.track
    val accent = c.accent
    Box(Modifier.size(188.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 18.dp.toPx()
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(stroke / 2, stroke / 2)
            drawArc(
                color = track,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(stroke),
            )
            if (result.fraction > 0f) {
                drawArc(
                    color = accent,
                    startAngle = -90f,
                    sweepAngle = 360f * result.fraction,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(stroke),
                )
            }
        }
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                result.hours,
                color = c.text,
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
            )
            Text("remaining at this rate", color = c.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text("$charge% charge", color = c.muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun EditForm(plant: Plant, vm: CalculatorViewModel) {
    val c = LocalSolarColors.current
    val focus = LocalFocusManager.current
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Edit plant", color = c.text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
            Button(
                onClick = {
                    focus.clearFocus()
                    vm.stopEditing()
                },
                modifier = Modifier.height(44.dp),
                contentPadding = PaddingValues(start = 12.dp, end = 16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = c.accentStrong, contentColor = c.onAccentStrong),
            ) {
                Icon(SolarIcons.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Done", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }

        LabeledField("Name and address, one line each") {
            SolarField(
                value = plant.name,
                onChange = { v -> vm.update { it.copy(name = v) } },
                placeholder = "Street or place, town, parish",
                keyboardType = KeyboardType.Text,
                minLines = 3,
                maxLines = 4,
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LabeledField("Factory (kWh)", Modifier.weight(1f)) {
                SolarField(plant.factory, { v -> vm.update { it.copy(factory = filterDecimal(v)) } }, "10")
            }
            LabeledField("Current (kWh)", Modifier.weight(1f)) {
                SolarField(plant.current, { v -> vm.update { it.copy(current = filterDecimal(v)) } }, "Optional")
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Bottom) {
            LabeledField("Reserve (%)", Modifier.weight(1f)) {
                SolarField(plant.reserve, { v -> vm.update { it.copy(reserve = filterDecimal(v)) } }, "20")
            }
            Text(
                "Current capacity replaces factory capacity when filled in.",
                color = c.muted,
                fontSize = 12.sp,
                modifier = Modifier
                    .weight(1f)
                    .padding(bottom = 4.dp),
            )
        }

        val confirm = vm.confirmDelete
        Button(
            onClick = vm::requestDelete,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (confirm) c.warn else c.card,
                contentColor = if (confirm) c.onWarn else c.warn,
            ),
            border = BorderStroke(1.dp, c.warn),
        ) {
            Text(
                if (confirm) "Tap again to delete this plant" else "Delete plant",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun Controls(plant: Plant, result: CalcResult, start: LocalDateTime, vm: CalculatorViewModel) {
    Column(
        Modifier.padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("Usable", result.usable, Modifier.weight(1f))
            Tile("Reserve", result.reserve, Modifier.weight(1f))
            Tile("Available", result.available, Modifier.weight(1f))
        }
        ChargeCard(plant, vm)
        LoadCard(plant, vm)
        TimeCard(start, vm)
    }
}

@Composable
private fun ChargeCard(plant: Plant, vm: CalculatorViewModel) {
    val c = LocalSolarColors.current
    Column(
        Modifier
            .fillMaxWidth()
            .surface(SmallCardShape, c.card, c.border)
            .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 6.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Charge now", color = c.muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("${plant.charge}%", color = c.text, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
        }
        Slider(
            value = plant.charge.toFloat(),
            onValueChange = { v -> vm.update { it.copy(charge = v.roundToInt()) } },
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(
                thumbColor = c.accentStrong,
                activeTrackColor = c.accent,
                inactiveTrackColor = c.track,
            ),
        )
    }
}

@Composable
private fun LoadCard(plant: Plant, vm: CalculatorViewModel) {
    val c = LocalSolarColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .surface(SmallCardShape, c.card, c.border)
            .padding(start = 16.dp, end = 12.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text("Power draw", color = c.muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            BasicTextField(
                value = plant.load,
                onValueChange = { v -> vm.update { it.copy(load = filterDecimal(v)) } },
                singleLine = true,
                textStyle = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = c.text),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                cursorBrush = SolidColor(c.accentStrong),
                decorationBox = { inner ->
                    Box {
                        if (plant.load.isEmpty()) {
                            Text(
                                "0",
                                color = c.muted.copy(alpha = 0.65f),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                            )
                        }
                        inner()
                    }
                },
            )
        }
        SegmentedToggle(
            options = listOf("W", "kW"),
            selected = if (plant.unit == PowerUnit.W) 0 else 1,
            onSelect = { i -> vm.update { it.copy(unit = if (i == 0) PowerUnit.W else PowerUnit.KW) } },
        )
    }
}

@Composable
private fun TimeCard(start: LocalDateTime, vm: CalculatorViewModel) {
    val c = LocalSolarColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .surface(SmallCardShape, c.card, c.border)
            .padding(start = 16.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text("Current time", color = c.muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            RoundIconButton(SolarIcons.Minus, "Earlier by 15 minutes") { vm.stepTime(-15) }
            Text(
                Calculator.stamp(start, withDate = false),
                color = if (vm.timeOffsetMin != 0) c.accentStrong else c.text,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .widthIn(min = 84.dp)
                    .clickable(onClickLabel = "Reset to the current time") { vm.resetTime() }
                    .padding(vertical = 12.dp),
            )
            RoundIconButton(SolarIcons.Plus, "Later by 15 minutes") { vm.stepTime(15) }
        }
    }
}
