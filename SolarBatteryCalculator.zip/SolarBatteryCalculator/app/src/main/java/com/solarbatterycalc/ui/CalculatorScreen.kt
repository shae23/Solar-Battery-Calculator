package com.solarbatterycalc.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarbatterycalc.CalculatorViewModel
import com.solarbatterycalc.Hourly
import com.solarbatterycalc.PowerUnit

fun filterDecimal(s: String): String {
    var seenDot = false
    return buildString {
        for (ch in s) {
            when {
                ch in '0'..'9' -> append(ch)
                (ch == '.' || ch == ',') && !seenDot -> {
                    append('.')
                    seenDot = true
                }
            }
        }
    }
}

fun filterDigits(s: String, maxLength: Int): String =
    s.filter { it in '0'..'9' }.take(maxLength)

@Composable
fun CalculatorScreen(vm: CalculatorViewModel) {
    val c = LocalSolarColors.current
    val result = vm.result

    Box(
        Modifier
            .fillMaxSize()
            .background(c.bg)
            .systemBarsPadding()
            .imePadding(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .widthIn(max = 480.dp)
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 40.dp),
        ) {
            Text("Solar Battery Calculator", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "Usable capacity from reserve, then runway at your current load.",
                color = c.muted,
                fontSize = 13.6.sp,
                modifier = Modifier.padding(top = 2.dp, bottom = 14.dp),
            )

            PlantCard(vm)

            SectionCard("Battery & Reserve") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LabeledField(
                        label = "Capacity (kWh)",
                        value = vm.capacity,
                        onChange = { vm.capacity = filterDecimal(it) },
                        placeholder = "e.g. 10",
                        keyboard = KeyboardType.Decimal,
                        modifier = Modifier.weight(1f),
                    )
                    LabeledField(
                        label = "Reserve (%)",
                        value = vm.reserve,
                        onChange = { vm.reserve = filterDecimal(it) },
                        placeholder = "e.g. 20",
                        keyboard = KeyboardType.Decimal,
                        modifier = Modifier.weight(1f),
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Stat("Usable", result.usable, Modifier.weight(1f))
                    Stat("Reserve", result.reserve, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Stat("Currently usable", result.currentUsable, Modifier.fillMaxWidth(), highlight = true)
            }

            SectionCard("Current Load") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LabeledField(
                        label = "Charge now (%)",
                        value = vm.currentPct,
                        onChange = { vm.currentPct = filterDecimal(it) },
                        placeholder = "e.g. 100",
                        keyboard = KeyboardType.Decimal,
                        modifier = Modifier.weight(0.8f),
                    )
                    Column(Modifier.weight(1.2f)) {
                        FieldLabel("Power draw")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Field(
                                value = vm.load,
                                onChange = { vm.load = filterDecimal(it) },
                                placeholder = "e.g. 800",
                                keyboard = KeyboardType.Decimal,
                                modifier = Modifier.weight(1f),
                            )
                            Spacer(Modifier.width(8.dp))
                            Toggle(
                                options = listOf("W", "kW"),
                                selected = if (vm.unit == PowerUnit.W) 0 else 1,
                                onSelect = { vm.unit = if (it == 0) PowerUnit.W else PowerUnit.KW },
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                FieldLabel("Current time")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Field(
                        value = vm.startHour,
                        onChange = { vm.startHour = filterDigits(it, 2) },
                        placeholder = "hh",
                        keyboard = KeyboardType.Number,
                        center = true,
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    Field(
                        value = vm.startMinute,
                        onChange = { vm.startMinute = filterDigits(it, 2) },
                        placeholder = "mm",
                        keyboard = KeyboardType.Number,
                        center = true,
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(8.dp))
                    Toggle(
                        options = listOf("AM", "PM"),
                        selected = if (vm.isPm) 1 else 0,
                        onSelect = { vm.isPm = it == 1 },
                    )
                }
            }

            RunwayCard(vm)
            HourlyCard(vm)
        }
    }
}

@Composable
private fun PlantCard(vm: CalculatorViewModel) {
    val c = LocalSolarColors.current
    val nameFocus = remember { FocusRequester() }
    var menuOpen by remember { mutableStateOf(false) }
    val noneLabel = "-- none selected --"

    SectionCard("Plant") {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) {
                FieldLabel("Saved plants")
                Box {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .clip(FieldShape)
                            .background(c.bg)
                            .border(1.dp, c.border, FieldShape)
                            .clickable { menuOpen = true }
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            vm.selectedPlant ?: noneLabel,
                            color = c.text,
                            fontSize = 16.sp,
                            maxLines = 1,
                            modifier = Modifier.weight(1f),
                        )
                        Text("\u25BE", color = c.muted, fontSize = 14.sp)
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(noneLabel) },
                            onClick = {
                                vm.selectPlant(null)
                                menuOpen = false
                            },
                        )
                        vm.plantNames.forEach { name ->
                            DropdownMenuItem(
                                text = { Text(name) },
                                onClick = {
                                    vm.selectPlant(name)
                                    menuOpen = false
                                },
                            )
                        }
                    }
                }
            }
            LabeledField(
                label = "Save as",
                value = vm.plantName,
                onChange = { vm.plantName = it },
                placeholder = "e.g. Mom's house",
                keyboard = KeyboardType.Text,
                modifier = Modifier.weight(1f),
                focusRequester = nameFocus,
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { if (!vm.savePlant()) nameFocus.requestFocus() },
                modifier = Modifier.weight(1f),
                shape = FieldShape,
                colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = Color.White),
                border = BorderStroke(1.dp, c.border),
            ) { Text("Save plant", fontSize = 13.6.sp) }
            Button(
                onClick = { vm.deletePlant() },
                modifier = Modifier.weight(1f),
                shape = FieldShape,
                colors = ButtonDefaults.buttonColors(containerColor = c.bg, contentColor = c.warn),
                border = BorderStroke(1.dp, c.border),
            ) { Text("Delete", fontSize = 13.6.sp) }
        }
    }
}

@Composable
private fun RunwayCard(vm: CalculatorViewModel) {
    val c = LocalSolarColors.current
    val r = vm.result
    val fraction by animateFloatAsState(r.barFraction, label = "bar")

    Column(
        Modifier
            .padding(bottom = 12.dp)
            .fillMaxWidth()
            .clip(CardShape)
            .background(c.card)
            .border(1.dp, c.border, CardShape)
            .padding(horizontal = 12.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(r.hours, color = c.accent, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("remaining at this rate", color = c.muted, fontSize = 13.6.sp, modifier = Modifier.padding(top = 4.dp))

        val eta = r.etaTime
        if (eta != null) {
            Text(
                buildAnnotatedString {
                    append(r.etaText)
                    withStyle(SpanStyle(color = c.good, fontWeight = FontWeight.Bold)) { append(eta) }
                },
                color = c.text,
                fontSize = 16.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 10.dp),
            )
        } else {
            Text(
                r.etaText,
                color = c.text,
                fontSize = 16.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 10.dp),
            )
        }

        Box(
            Modifier
                .padding(top = 10.dp)
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(c.border),
        ) {
            Box(
                Modifier
                    .fillMaxWidth(fraction.coerceIn(0f, 1f))
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(6.dp))
                    .background(c.accent),
            )
        }

        if (r.flag.isNotEmpty()) {
            Text(
                r.flag,
                color = c.warn,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
            )
        }
    }
}

@Composable
private fun HourlyCard(vm: CalculatorViewModel) {
    val c = LocalSolarColors.current
    val rotation by animateFloatAsState(if (vm.hourlyOpen) 180f else 0f, label = "chevron")

    Column(
        Modifier
            .padding(bottom = 12.dp)
            .fillMaxWidth()
            .clip(CardShape)
            .background(c.card)
            .border(1.dp, c.border, CardShape)
            .padding(14.dp),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { vm.hourlyOpen = !vm.hourlyOpen },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("Hourly breakdown", color = c.text, fontSize = 13.6.sp, fontWeight = FontWeight.SemiBold)
            Text("\u25BE", color = c.muted, fontSize = 13.sp, modifier = Modifier.rotate(rotation))
        }

        if (vm.hourlyOpen) {
            Spacer(Modifier.height(10.dp))
            when (val h = vm.result.hourly) {
                is Hourly.Message -> Text(
                    h.text,
                    color = c.muted,
                    fontSize = 13.6.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                )
                is Hourly.Rows -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    h.rows.forEach { row ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(c.bg)
                                .border(1.dp, c.border, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                row.timeLabel,
                                color = c.text,
                                fontSize = 13.6.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.widthIn(min = 66.dp),
                            )
                            Text(
                                row.percent,
                                color = c.accent,
                                fontSize = 13.6.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.widthIn(min = 48.dp),
                            )
                            Text(row.kwh, color = c.muted, fontSize = 13.6.sp, textAlign = TextAlign.End)
                        }
                    }
                }
            }
        }
    }
}

private val CardShape = RoundedCornerShape(14.dp)
private val FieldShape = RoundedCornerShape(9.dp)

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalSolarColors.current
    Column(
        Modifier
            .padding(bottom = 12.dp)
            .fillMaxWidth()
            .clip(CardShape)
            .background(c.card)
            .border(1.dp, c.border, CardShape)
            .padding(14.dp),
    ) {
        Text(
            title.uppercase(),
            color = c.muted,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.5.sp,
            modifier = Modifier.padding(bottom = 10.dp),
        )
        content()
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(text, color = LocalSolarColors.current.text, fontSize = 12.5.sp, modifier = Modifier.padding(bottom = 4.dp))
}

@Composable
private fun LabeledField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    keyboard: KeyboardType,
    modifier: Modifier = Modifier,
    focusRequester: FocusRequester? = null,
) {
    Column(modifier) {
        FieldLabel(label)
        Field(value, onChange, placeholder, keyboard, Modifier, focusRequester = focusRequester)
    }
}

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    keyboard: KeyboardType,
    modifier: Modifier = Modifier,
    center: Boolean = false,
    focusRequester: FocusRequester? = null,
) {
    val c = LocalSolarColors.current
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        placeholder = { Text(placeholder, color = c.muted.copy(alpha = 0.65f), modifier = if (center) Modifier.fillMaxWidth() else Modifier, textAlign = if (center) TextAlign.Center else TextAlign.Start) },
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        textStyle = TextStyle(fontSize = 16.sp, textAlign = if (center) TextAlign.Center else TextAlign.Start),
        shape = FieldShape,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = c.text,
            unfocusedTextColor = c.text,
            focusedContainerColor = c.bg,
            unfocusedContainerColor = c.bg,
            focusedBorderColor = c.accent,
            unfocusedBorderColor = c.border,
            cursorColor = c.accent,
        ),
        modifier = modifier
            .fillMaxWidth()
            .let { if (focusRequester != null) it.focusRequester(focusRequester) else it },
    )
}

@Composable
private fun Toggle(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalSolarColors.current
    Row(
        Modifier
            .height(56.dp)
            .clip(FieldShape)
            .border(1.dp, c.border, FieldShape),
    ) {
        options.forEachIndexed { index, label ->
            val active = index == selected
            Box(
                Modifier
                    .fillMaxHeight()
                    .background(if (active) c.accent else c.bg)
                    .clickable { onSelect(index) }
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = if (active) Color.White else c.muted, fontSize = 14.4.sp)
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier = Modifier, highlight: Boolean = false) {
    val c = LocalSolarColors.current
    Column(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(c.accentSoft)
            .padding(12.dp),
    ) {
        Text(label.uppercase(), color = c.muted, fontSize = 11.5.sp, letterSpacing = 0.4.sp)
        Text(
            value,
            color = if (highlight) c.accent else c.text,
            fontSize = if (highlight) 22.4.sp else 18.4.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 3.dp),
        )
    }
}
