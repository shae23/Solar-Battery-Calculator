package com.solarbatterycalc.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.time.LocalDateTime
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

private enum class DialMode { Hour, Minute }

private fun twoDigits(n: Int) = String.format(Locale.US, "%02d", n)

@Composable
fun SolarTimePickerDialog(
    initial: LocalDateTime,
    onConfirm: (hour24: Int, minute: Int) -> Unit,
    onNow: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = LocalSolarColors.current
    val focus = LocalFocusManager.current

    val startHour12 = if (initial.hour % 12 == 0) 12 else initial.hour % 12
    var hourField by remember { mutableStateOf(TextFieldValue(startHour12.toString())) }
    var minuteField by remember { mutableStateOf(TextFieldValue(twoDigits(initial.minute))) }
    var pm by remember { mutableStateOf(initial.hour >= 12) }
    var mode by remember { mutableStateOf(DialMode.Hour) }

    val hour = (hourField.text.toIntOrNull() ?: 12).coerceIn(1, 12)
    val minute = (minuteField.text.toIntOrNull() ?: 0).coerceIn(0, 59)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = c.card,
            tonalElevation = 0.dp,
            modifier = Modifier.width(328.dp),
        ) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Set the time", color = c.muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        TimeField(
                            value = hourField,
                            active = mode == DialMode.Hour,
                            label = "Hour",
                            onChange = { v -> hourField = v.copy(text = v.text.filter { it.isDigit() }.take(2)) },
                            onFocus = {
                                mode = DialMode.Hour
                                hourField = hourField.copy(selection = TextRange(0, hourField.text.length))
                            },
                            onBlur = { hourField = TextFieldValue(hour.toString()) },
                        )
                        Text(":", color = c.text, fontSize = 48.sp, fontWeight = FontWeight.ExtraBold)
                        TimeField(
                            value = minuteField,
                            active = mode == DialMode.Minute,
                            label = "Minute",
                            onChange = { v -> minuteField = v.copy(text = v.text.filter { it.isDigit() }.take(2)) },
                            onFocus = {
                                mode = DialMode.Minute
                                minuteField = minuteField.copy(selection = TextRange(0, minuteField.text.length))
                            },
                            onBlur = { minuteField = TextFieldValue(twoDigits(minute)) },
                        )
                    }
                    AmPmToggle(pm) { pm = it }
                }

                Text(
                    "Tap the hour or minute to type it, or use the dial.",
                    color = c.muted,
                    fontSize = 12.sp,
                )

                ClockDial(
                    mode = mode,
                    hour = hour,
                    minute = minute,
                    onSetHour = { h ->
                        focus.clearFocus()
                        hourField = TextFieldValue(h.toString())
                    },
                    onSetMinute = { m ->
                        focus.clearFocus()
                        minuteField = TextFieldValue(twoDigits(m))
                    },
                    onRelease = { if (mode == DialMode.Hour) mode = DialMode.Minute },
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                )

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onNow) { Text("Now", color = c.accentStrong) }
                    TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) }
                    TextButton(onClick = { onConfirm(hour % 12 + if (pm) 12 else 0, minute) }) {
                        Text("OK", color = c.accentStrong)
                    }
                }
            }
        }
    }
}

@Composable
private fun TimeField(
    value: TextFieldValue,
    active: Boolean,
    label: String,
    onChange: (TextFieldValue) -> Unit,
    onFocus: () -> Unit,
    onBlur: () -> Unit,
) {
    val c = LocalSolarColors.current
    val shape = RoundedCornerShape(16.dp)
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(
            fontSize = 48.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (active) c.accentStrong else c.text,
            textAlign = TextAlign.Center,
        ),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        cursorBrush = SolidColor(c.accentStrong),
        modifier = Modifier
            .size(width = 96.dp, height = 80.dp)
            .onFocusChanged { if (it.isFocused) onFocus() else onBlur() }
            .semantics { contentDescription = label },
        decorationBox = { inner ->
            Box(
                Modifier
                    .fillMaxSize()
                    .clip(shape)
                    .background(if (active) c.accentSoft else c.bg)
                    .border(2.dp, if (active) c.accentStrong else Color.Transparent, shape),
                contentAlignment = Alignment.Center,
            ) {
                inner()
            }
        },
    )
}

@Composable
private fun AmPmToggle(pm: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalSolarColors.current
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .clip(shape)
            .border(1.dp, c.inputBorder, shape),
    ) {
        listOf(false to "AM", true to "PM").forEach { (value, label) ->
            val on = pm == value
            Box(
                Modifier
                    .width(52.dp)
                    .height(40.dp)
                    .background(if (on) c.accentStrong else c.card)
                    .clickable { onChange(value) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    color = if (on) c.onAccentStrong else c.text,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun ClockDial(
    mode: DialMode,
    hour: Int,
    minute: Int,
    onSetHour: (Int) -> Unit,
    onSetMinute: (Int) -> Unit,
    onRelease: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = LocalSolarColors.current
    val handColor = c.accentStrong
    val hourMode = mode == DialMode.Hour
    val angleRad = Math.toRadians(if (hourMode) (hour % 12) * 30.0 else minute * 6.0)
    val ringRadius = 100.dp

    val applyPoint: (Offset, IntSize) -> Unit = { point, box ->
        val dx = point.x - box.width / 2f
        val dy = point.y - box.height / 2f
        var deg = Math.toDegrees(atan2(dx.toDouble(), -dy.toDouble()))
        if (deg < 0) deg += 360.0
        if (hourMode) {
            var h = (deg / 30).roundToInt() % 12
            if (h == 0) h = 12
            onSetHour(h)
        } else {
            onSetMinute((deg / 6).roundToInt() % 60)
        }
    }

    Box(
        modifier
            .size(256.dp)
            .clip(CircleShape)
            .background(c.bg)
            .pointerInput(mode) {
                detectTapGestures(onTap = { p ->
                    applyPoint(p, size)
                    onRelease()
                })
            }
            .pointerInput(mode) {
                detectDragGestures(
                    onDragStart = { p -> applyPoint(p, size) },
                    onDragEnd = { onRelease() },
                    onDrag = { change, _ -> applyPoint(change.position, size) },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = ringRadius.toPx()
            val center = Offset(size.width / 2f, size.height / 2f)
            val end = Offset(
                center.x + (r * sin(angleRad)).toFloat(),
                center.y - (r * cos(angleRad)).toFloat(),
            )
            drawLine(color = handColor, start = center, end = end, strokeWidth = 2.dp.toPx())
            drawCircle(color = handColor, radius = 4.dp.toPx(), center = center)
        }

        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0)
            val label = if (hourMode) (if (i == 0) "12" else i.toString()) else twoDigits(i * 5)
            Box(
                Modifier
                    .offset(x = (100 * sin(a)).dp, y = (-100 * cos(a)).dp)
                    .size(40.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        Box(
            Modifier
                .offset(x = (100 * sin(angleRad)).dp, y = (-100 * cos(angleRad)).dp)
                .size(40.dp)
                .clip(CircleShape)
                .background(handColor),
            contentAlignment = Alignment.Center,
        ) {
            val knobText = if (hourMode) hour.toString() else if (minute % 5 == 0) twoDigits(minute) else ""
            Text(knobText, color = c.onAccentStrong, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
