package com.solarbatterycalc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.solarbatterycalc.ui.CalculatorScreen
import com.solarbatterycalc.ui.SolarTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SolarTheme {
                CalculatorScreen(viewModel<CalculatorViewModel>())
            }
        }
    }
}
