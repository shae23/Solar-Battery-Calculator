package com.solarbatterycalc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.solarbatterycalc.ui.SolarApp
import com.solarbatterycalc.ui.SolarTheme

class MainActivity : ComponentActivity() {
    private val vm: CalculatorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SolarTheme {
                SolarApp(vm)
            }
        }
    }
}
