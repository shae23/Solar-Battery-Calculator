package com.solarbatterycalc

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import java.util.UUID
import kotlin.math.max

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {
    private val store = PlantStore(application)

    var plants by mutableStateOf(emptyList<Plant>())
        private set
    var activeId by mutableStateOf<String?>(null)
        private set
    var editing by mutableStateOf(false)
        private set
    var confirmDelete by mutableStateOf(false)
        private set
    var timeOffsetMin by mutableIntStateOf(0)
        private set

    val activeIndex: Int
        get() = plants.indexOfFirst { it.id == activeId }

    val active: Plant?
        get() = plants.getOrNull(activeIndex)

    init {
        val saved = store.load()
        plants = saved.plants
        activeId = saved.activeId?.takeIf { id -> saved.plants.any { it.id == id } }
            ?: saved.plants.firstOrNull()?.id
        if (plants.isNotEmpty()) persist()
    }

    private fun persist() = store.save(StoredState(plants, activeId))

    fun select(index: Int) {
        val plant = plants.getOrNull(index) ?: return
        if (plant.id == activeId) return
        activeId = plant.id
        confirmDelete = false
        persist()
    }

    fun toggleEdit(id: String) {
        if (id != activeId) {
            activeId = id
            editing = true
        } else {
            editing = !editing
        }
        confirmDelete = false
        persist()
    }

    fun stopEditing() {
        editing = false
        confirmDelete = false
    }

    fun addPlant() {
        val plant = Plant(id = UUID.randomUUID().toString())
        plants = plants + plant
        activeId = plant.id
        editing = true
        confirmDelete = false
        persist()
    }

    fun update(transform: (Plant) -> Plant) {
        val id = activeId ?: return
        plants = plants.map { if (it.id == id) transform(it) else it }
        persist()
    }

    fun requestDelete() {
        if (!confirmDelete) {
            confirmDelete = true
            return
        }
        val index = activeIndex
        val left = plants.filter { it.id != activeId }
        plants = left
        activeId = left.getOrNull(max(0, index - 1))?.id
        editing = false
        confirmDelete = false
        persist()
    }

    fun stepTime(deltaMinutes: Int) {
        timeOffsetMin += deltaMinutes
    }

    fun resetTime() {
        timeOffsetMin = 0
    }
}
