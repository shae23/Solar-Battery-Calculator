package com.solarbatterycalc

import android.app.Application
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import java.util.Calendar
import java.util.Locale

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {
    private val store = PlantStore(application)
    private var saved: Map<String, Plant> = store.load()

    var capacity by mutableStateOf("")
    var reserve by mutableStateOf("")
    var currentPct by mutableStateOf("")
    var load by mutableStateOf("")
    var unit by mutableStateOf(PowerUnit.W)
    var startHour by mutableStateOf("")
    var startMinute by mutableStateOf("")
    var isPm by mutableStateOf(false)
    var hourlyOpen by mutableStateOf(false)
    var plantName by mutableStateOf("")
    var selectedPlant by mutableStateOf<String?>(null)
    var plantNames by mutableStateOf(saved.keys.sorted())
        private set

    val result: CalcResult by derivedStateOf {
        Calculator.compute(
            Inputs(capacity, reserve, currentPct, load, unit, startHour, startMinute, isPm),
        )
    }

    init {
        val now = Calendar.getInstance()
        val h24 = now.get(Calendar.HOUR_OF_DAY)
        var h12 = h24 % 12
        if (h12 == 0) h12 = 12
        startHour = h12.toString()
        startMinute = String.format(Locale.US, "%02d", now.get(Calendar.MINUTE))
        isPm = h24 >= 12
    }

    fun selectPlant(name: String?) {
        selectedPlant = name
        val plant = name?.let { saved[it] } ?: return
        capacity = plant.capacity
        reserve = plant.reserve
    }

    fun savePlant(): Boolean {
        val name = plantName.trim()
        if (name.isEmpty()) return false
        saved = saved + (name to Plant(capacity, reserve))
        store.save(saved)
        plantNames = saved.keys.sorted()
        selectedPlant = name
        plantName = ""
        return true
    }

    fun deletePlant() {
        val name = selectedPlant ?: return
        saved = saved - name
        store.save(saved)
        plantNames = saved.keys.sorted()
        selectedPlant = null
    }
}
