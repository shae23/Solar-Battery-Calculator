package com.solarbatterycalc.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val CardShape = RoundedCornerShape(24.dp)
val SmallCardShape = RoundedCornerShape(18.dp)
val FieldShape = RoundedCornerShape(14.dp)

fun filterDecimal(s: String): String {
    var seenDot = false
    return buildString {
        for (ch in s) {
            when {
                ch in '0'..'9' -> append(ch)
                (ch == '.' || ch == ',') && !seenDot -> {
                    append('.')
                    seenDot = true
                }
            }
        }
    }
}

fun Modifier.surface(shape: Shape, color: Color, border: Color): Modifier =
    this.clip(shape).background(color, shape).border(1.dp, border, shape)

@Composable
fun LabeledField(label: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Column(modifier) {
        Text(
            label,
            color = LocalSolarColors.current.muted,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 6.dp),
        )
        content()
    }
}

@Composable
fun SolarField(
    value: String,
    onChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Decimal,
    minLines: Int = 1,
    maxLines: Int = 1,
) {
    val c = LocalSolarColors.current
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = maxLines == 1,
        minLines = minLines,
        maxLines = maxLines,
        placeholder = { Text(placeholder, color = c.muted.copy(alpha = 0.65f)) },
        keyboardOptions = KeyboardOptions(
            keyboardType = keyboardType,
            capitalization = if (keyboardType == KeyboardType.Text) KeyboardCapitalization.Words else KeyboardCapitalization.None,
        ),
        textStyle = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
        shape = FieldShape,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = c.text,
            unfocusedTextColor = c.text,
            focusedContainerColor = c.card,
            unfocusedContainerColor = c.card,
            focusedBorderColor = c.accentStrong,
            unfocusedBorderColor = c.inputBorder,
            cursorColor = c.accentStrong,
        ),
        modifier = modifier.fillMaxWidth(),
    )
}

@Composable
fun Tile(label: String, value: String, modifier: Modifier = Modifier) {
    val c = LocalSolarColors.current
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(c.accentSoft)
            .padding(horizontal = 12.dp, vertical = 10.dp),
    ) {
        Text(
            label.uppercase(),
            color = c.muted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.4.sp,
        )
        Text(
            value,
            color = c.text,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            modifier = Modifier.padding(top = 2.dp),
        )
    }
}

@Composable
fun SegmentedToggle(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalSolarColors.current
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier
            .height(44.dp)
            .clip(shape)
            .border(1.dp, c.border, shape),
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier
                    .width(52.dp)
                    .fillMaxHeight()
                    .background(if (on) c.accentStrong else c.bg)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    color = if (on) c.onAccentStrong else c.muted,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
fun RoundIconButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    val c = LocalSolarColors.current
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(c.bg)
            .border(1.dp, c.border, CircleShape)
            .clickable(onClickLabel = description, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = c.text, modifier = Modifier.size(20.dp))
    }
}

@Composable
fun AddPlantButton(onClick: () -> Unit) {
    val c = LocalSolarColors.current
    val dashColor = c.inputBorder
    Row(
        Modifier
            .height(40.dp)
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .drawBehind {
                drawRoundRect(
                    color = dashColor,
                    cornerRadius = CornerRadius(20.dp.toPx()),
                    style = Stroke(
                        width = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f),
                    ),
                )
            }
            .padding(start = 12.dp, end = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(SolarIcons.Plus, contentDescription = null, tint = c.muted, modifier = Modifier.size(18.dp))
        Text("Add plant", color = c.muted, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}
