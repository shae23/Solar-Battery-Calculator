package com.solarbatterycalc.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.solarbatterycalc.CalculatorViewModel
import com.solarbatterycalc.Plant
import kotlin.math.absoluteValue

private fun pageAlpha(state: PagerState, page: Int): Float {
    val offset = ((state.currentPage - page) + state.currentPageOffsetFraction).absoluteValue
    return 1f - 0.45f * offset.coerceIn(0f, 1f)
}

@Composable
fun PlantPager(
    vm: CalculatorViewModel,
    userScroll: Boolean,
    content: @Composable (page: Int, plant: Plant) -> Unit,
) {
    val state = rememberPagerState(initialPage = vm.activeIndex.coerceAtLeast(0)) { vm.plants.size }

    LaunchedEffect(state) {
        snapshotFlow { state.settledPage }.collect { vm.select(it) }
    }
    val index = vm.activeIndex
    LaunchedEffect(index) {
        if (index >= 0 && index != state.currentPage) state.animateScrollToPage(index)
    }

    HorizontalPager(
        state = state,
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 36.dp),
        pageSpacing = 12.dp,
        userScrollEnabled = userScroll,
        verticalAlignment = Alignment.Top,
    ) { page ->
        val plant = vm.plants.getOrNull(page)
        if (plant != null) {
            Box(Modifier.graphicsLayer { alpha = pageAlpha(state, page) }) {
                content(page, plant)
            }
        }
    }
}

@Composable
fun DotsRow(vm: CalculatorViewModel, showAdd: Boolean) {
    val c = LocalSolarColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .height(44.dp),
        horizontalArrangement = if (showAdd) Arrangement.SpaceBetween else Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            vm.plants.forEachIndexed { i, plant ->
                Box(
                    Modifier
                        .width(24.dp)
                        .height(44.dp)
                        .clickable(onClickLabel = "Show plant ${i + 1}") { vm.select(i) },
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (plant.id == vm.activeId) c.accentStrong else c.dot),
                    )
                }
            }
        }
        if (showAdd) AddPlantButton(onClick = vm::addPlant)
    }
}
