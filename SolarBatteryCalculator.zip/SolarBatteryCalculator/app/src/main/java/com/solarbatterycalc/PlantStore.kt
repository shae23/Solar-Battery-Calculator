package com.solarbatterycalc

import android.content.Context
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

data class StoredState(val plants: List<Plant>, val activeId: String?)

class PlantStore(context: Context) {
    private val prefs = context.getSharedPreferences("solarCalc", Context.MODE_PRIVATE)

    fun load(): StoredState {
        val raw = prefs.getString(KEY_V2, null)
        if (raw != null) {
            return try {
                parse(raw)
            } catch (e: Exception) {
                StoredState(emptyList(), null)
            }
        }
        return migrateOld()
    }

    fun save(state: StoredState) {
        val arr = JSONArray()
        state.plants.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("factory", p.factory)
                    .put("current", p.current)
                    .put("reserve", p.reserve)
                    .put("charge", p.charge)
                    .put("load", p.load)
                    .put("unit", p.unit.name),
            )
        }
        val root = JSONObject().put("plants", arr).put("active", state.activeId ?: "")
        prefs.edit().putString(KEY_V2, root.toString()).apply()
    }

    private fun parse(raw: String): StoredState {
        val root = JSONObject(raw)
        val arr = root.getJSONArray("plants")
        val list = ArrayList<Plant>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list += Plant(
                id = o.getString("id"),
                name = o.optString("name"),
                factory = o.optString("factory"),
                current = o.optString("current"),
                reserve = o.optString("reserve"),
                charge = o.optInt("charge", 100).coerceIn(0, 100),
                load = o.optString("load"),
                unit = if (o.optString("unit") == "KW") PowerUnit.KW else PowerUnit.W,
            )
        }
        return StoredState(list, root.optString("active").ifEmpty { null })
    }

    // Plants saved by the first version of the app: name -> capacity and reserve.
    private fun migrateOld(): StoredState {
        val raw = prefs.getString(KEY_V1, null) ?: return StoredState(emptyList(), null)
        return try {
            val obj = JSONObject(raw)
            val plants = obj.keys().asSequence().sorted().map { name ->
                val p = obj.getJSONObject(name)
                Plant(
                    id = UUID.randomUUID().toString(),
                    name = name,
                    factory = p.optString("capacity"),
                    reserve = p.optString("reserve"),
                )
            }.toList()
            StoredState(plants, plants.firstOrNull()?.id)
        } catch (e: Exception) {
            StoredState(emptyList(), null)
        }
    }

    private companion object {
        const val KEY_V1 = "plants"
        const val KEY_V2 = "plants_v2"
    }
}
