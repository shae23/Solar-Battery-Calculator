package com.solarbatterycalc

import android.content.Context
import org.json.JSONObject

data class Plant(val capacity: String, val reserve: String)

class PlantStore(context: Context) {
    private val prefs = context.getSharedPreferences("solarCalc", Context.MODE_PRIVATE)

    fun load(): Map<String, Plant> {
        val raw = prefs.getString(KEY, null) ?: return emptyMap()
        return try {
            val obj = JSONObject(raw)
            buildMap {
                obj.keys().forEach { name ->
                    val p = obj.getJSONObject(name)
                    put(name, Plant(p.optString("capacity"), p.optString("reserve")))
                }
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun save(plants: Map<String, Plant>) {
        val obj = JSONObject()
        plants.forEach { (name, p) ->
            obj.put(name, JSONObject().put("capacity", p.capacity).put("reserve", p.reserve))
        }
        prefs.edit().putString(KEY, obj.toString()).apply()
    }

    private companion object {
        const val KEY = "plants"
    }
}
