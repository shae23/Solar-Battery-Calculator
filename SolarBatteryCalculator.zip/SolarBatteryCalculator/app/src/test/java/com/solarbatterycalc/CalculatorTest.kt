package com.solarbatterycalc

import java.time.LocalDateTime
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CalculatorTest {
    private val eightPm = LocalDateTime.of(2026, 10, 6, 20, 0)

    private fun plant(
        factory: String = "10",
        current: String = "",
        reserve: String = "20",
        charge: Int = 100,
        load: String = "800",
        unit: PowerUnit = PowerUnit.W,
    ) = Plant("p", "Home", factory, current, reserve, charge, load, unit)

    @Test
    fun fullBatteryOnFactoryCapacity() {
        val r = Calculator.compute(plant(), eightPm)
        assertEquals("8.00 kWh", r.usable)
        assertEquals("2.00 kWh", r.reserve)
        assertEquals("8.00 kWh", r.available)
        assertEquals("10 h 0 m", r.hours)
        assertEquals("Oct 7, 6:00 AM", r.runsOut)
        assertEquals(1f, r.fraction, 0.0001f)
        assertEquals("", r.flag)
    }

    @Test
    fun currentCapacityOverridesFactory() {
        val r = Calculator.compute(plant(factory = "10", current = "8"), eightPm)
        assertEquals("6.40 kWh", r.usable)
        assertEquals("1.60 kWh", r.reserve)
        assertEquals("8 h 0 m", r.hours)
        assertEquals("Oct 7, 4:00 AM", r.runsOut)
    }

    @Test
    fun clearingCurrentFallsBackToFactory() {
        val withCurrent = Calculator.compute(plant(factory = "10", current = "8"), eightPm)
        val cleared = Calculator.compute(plant(factory = "10", current = ""), eightPm)
        assertEquals("6.40 kWh", withCurrent.usable)
        assertEquals("8.00 kWh", cleared.usable)
    }

    @Test
    fun currentAloneIsEnough() {
        val r = Calculator.compute(plant(factory = "", current = "5"), eightPm)
        assertTrue(r.hasCapacity)
        assertEquals("4.00 kWh", r.usable)
    }

    @Test
    fun noCapacityAtAll() {
        val r = Calculator.compute(plant(factory = "", current = ""), eightPm)
        assertFalse(r.hasCapacity)
        assertEquals(NO_KWH, r.usable)
        assertEquals(NO_HOURS, r.hours)
        assertNull(r.runsOut)
        assertEquals(MSG_NEEDS_CAPACITY, r.message)
        assertEquals(MSG_NEEDS_CAPACITY, Calculator.compute(plant(reserve = ""), eightPm).message)
    }

    @Test
    fun missingOrZeroLoad() {
        val none = Calculator.compute(plant(load = ""), eightPm)
        assertEquals("8.00 kWh", none.available)
        assertEquals(NO_HOURS, none.hours)
        assertEquals(MSG_NEEDS_LOAD, none.message)
        assertEquals(MSG_NEEDS_LOAD, Calculator.compute(plant(load = "0"), eightPm).message)
    }

    @Test
    fun kilowattsMatchWatts() {
        val w = Calculator.compute(plant(load = "800", unit = PowerUnit.W), eightPm)
        val kw = Calculator.compute(plant(load = "0.8", unit = PowerUnit.KW), eightPm)
        assertEquals(w.hours, kw.hours)
        assertEquals(w.runsOut, kw.runsOut)
    }

    @Test
    fun hourlyRowsStartWithNowAndCrossMidnight() {
        val rows = Calculator.compute(plant(), eightPm).rows
        assertEquals(11, rows.size)
        assertEquals(HourlyRow("Now", "100%", "8.00 kWh", 1f), rows[0])
        assertEquals("9:00 PM", rows[1].label)
        assertEquals("90%", rows[1].percent)
        assertEquals("7.20 kWh", rows[1].kwh)
        assertEquals("Oct 7, 12:00 AM", rows[4].label)
        assertEquals("Oct 7, 6:00 AM", rows[10].label)
        assertEquals("0%", rows[10].percent)
        assertEquals("0.00 kWh", rows[10].kwh)
    }

    @Test
    fun hourlyRowsCapAtTwentyFourSteps() {
        val rows = Calculator.compute(plant(load = "10"), eightPm).rows
        assertEquals(25, rows.size)
    }

    @Test
    fun runsOutOnALaterDate() {
        val midnight = LocalDateTime.of(2026, 10, 6, 0, 0)
        val r = Calculator.compute(plant(load = "100"), midnight)
        assertEquals("80 h 0 m", r.hours)
        assertEquals("Oct 9, 8:00 AM", r.runsOut)
    }

    @Test
    fun underAnHourFlag() {
        val r = Calculator.compute(plant(charge = 30, load = "2000"), eightPm)
        assertEquals("0 h 30 m", r.hours)
        assertEquals("Under an hour left at this rate", r.flag)
    }

    @Test
    fun atReserveLevel() {
        val r = Calculator.compute(plant(charge = 20), eightPm)
        assertEquals("0.00 kWh", r.available)
        assertEquals("0 h 0 m", r.hours)
        assertEquals("At or below reserve level", r.flag)
        assertTrue(r.rows.isEmpty())
    }

    @Test
    fun reserveClampsToHundred() {
        val r = Calculator.compute(plant(reserve = "150"), eightPm)
        assertEquals("0.00 kWh", r.usable)
        assertEquals("10.00 kWh", r.reserve)
        assertEquals(0f, r.fraction, 0.0001f)
    }

    @Test
    fun stampFormatting() {
        val t = LocalDateTime.of(2026, 1, 5, 0, 5)
        assertEquals("12:05 AM", Calculator.stamp(t, false))
        assertEquals("Jan 5, 12:05 AM", Calculator.stamp(t, true))
        assertEquals("12:30 PM", Calculator.stamp(LocalDateTime.of(2026, 1, 5, 12, 30), false))
        assertEquals("Dec 31, 11:59 PM", Calculator.stamp(LocalDateTime.of(2026, 12, 31, 23, 59), true))
    }

    @Test
    fun plantNameAndLabels() {
        val p = Plant("a", "27 Marvin's Park\nOcho Rios\nSt. Ann", "10", "8.6", "20")
        assertEquals("27 Marvin's Park", p.title)
        assertEquals("Ocho Rios\nSt. Ann", p.detail)
        assertEquals("Ocho Rios, St. Ann", p.detailInline)
        assertEquals("8.6 of 10 kWh, 20% reserve", p.capacityLabel)
        assertEquals("5 kWh, 30% reserve", Plant("b", "", "5", "", "30").capacityLabel)
        assertEquals("4 kWh, --% reserve", Plant("c", "", "", "4", "").capacityLabel)
        assertEquals("Unnamed", Plant("d").title)
    }

    @Test
    fun timeOfDayOffsets() {
        val now = LocalDateTime.of(2026, 10, 6, 22, 50)
        assertEquals(20, Calculator.offsetForTime(23, 10, now))
        assertEquals(-1360, Calculator.offsetForTime(0, 10, now))
        assertEquals(0, Calculator.offsetForTime(22, 50, now))
        val shifted = now.plusMinutes(Calculator.offsetForTime(6, 15, now).toLong())
        assertEquals(LocalDateTime.of(2026, 10, 6, 6, 15), shifted)
    }
}
