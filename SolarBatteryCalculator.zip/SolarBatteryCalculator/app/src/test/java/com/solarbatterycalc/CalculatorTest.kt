package com.solarbatterycalc

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CalculatorTest {
    private fun inputs(
        capacity: String = "10",
        reserve: String = "20",
        charge: String = "100",
        load: String = "800",
        unit: PowerUnit = PowerUnit.W,
        hour: String = "8",
        minute: String = "00",
        pm: Boolean = true,
    ) = Inputs(capacity, reserve, charge, load, unit, hour, minute, pm)

    @Test
    fun fullBatteryRunway() {
        val r = Calculator.compute(inputs())
        assertEquals("8.00 kWh", r.usable)
        assertEquals("2.00 kWh", r.reserve)
        assertEquals("8.00 kWh", r.currentUsable)
        assertEquals("10 h 0 m", r.hours)
        assertEquals("Runs out around ", r.etaText)
        assertEquals("6:00 AM (next day)", r.etaTime)
        assertEquals(1f, r.barFraction, 0.0001f)
        assertEquals("", r.flag)
    }

    @Test
    fun kilowattsMatchWatts() {
        val w = Calculator.compute(inputs(load = "800", unit = PowerUnit.W))
        val kw = Calculator.compute(inputs(load = "0.8", unit = PowerUnit.KW))
        assertEquals(w.hours, kw.hours)
    }

    @Test
    fun hourlyRowsStepDownAndCrossMidnight() {
        val rows = (Calculator.compute(inputs()).hourly as Hourly.Rows).rows
        assertEquals(10, rows.size)
        assertEquals(HourlyRow("9:00 PM", "90%", "7.20 kWh"), rows[0])
        assertEquals("12:00 AM (+1d)", rows[3].timeLabel)
        assertEquals(HourlyRow("6:00 AM (+1d)", "0%", "0.00 kWh"), rows[9])
    }

    @Test
    fun missingCapacityOrReserve() {
        val r = Calculator.compute(inputs(capacity = ""))
        assertEquals(NO_KWH, r.usable)
        assertEquals("Enter capacity and reserve to get started", r.etaText)
        val r2 = Calculator.compute(inputs(reserve = ""))
        assertEquals("Enter capacity and reserve to get started", r2.etaText)
    }

    @Test
    fun missingChargeAndLoad() {
        val noCharge = Calculator.compute(inputs(charge = ""))
        assertEquals("8.00 kWh", noCharge.usable)
        assertEquals("Enter your current charge to see runway", noCharge.etaText)
        val noLoad = Calculator.compute(inputs(load = ""))
        assertEquals("8.00 kWh", noLoad.currentUsable)
        assertEquals("Enter a load above zero", noLoad.etaText)
        val zeroLoad = Calculator.compute(inputs(load = "0"))
        assertEquals("Enter a load above zero", zeroLoad.etaText)
    }

    @Test
    fun underAnHourFlag() {
        val r = Calculator.compute(inputs(charge = "30", load = "2000"))
        assertEquals("0 h 30 m", r.hours)
        assertEquals("Under an hour left at this rate.", r.flag)
    }

    @Test
    fun atReserveLevel() {
        val r = Calculator.compute(inputs(charge = "20"))
        assertEquals("0.00 kWh", r.currentUsable)
        assertEquals("0 h 0 m", r.hours)
        assertEquals("Currently usable is zero, at or below reserve level.", r.flag)
        assertEquals(Hourly.Message(HOURLY_HINT), r.hourly)
    }

    @Test
    fun reserveClampsToHundred() {
        val r = Calculator.compute(inputs(reserve = "150"))
        assertEquals("0.00 kWh", r.usable)
        assertEquals("10.00 kWh", r.reserve)
        assertEquals(0f, r.barFraction, 0.0001f)
    }

    @Test
    fun hourlyCapsAtFortyEightRows() {
        val r = Calculator.compute(inputs(load = "10"))
        assertEquals(48, (r.hourly as Hourly.Rows).rows.size)
    }

    @Test
    fun multiDayEta() {
        val r = Calculator.compute(inputs(load = "100", hour = "12", minute = "00", pm = false))
        assertEquals("80 h 0 m", r.hours)
        assertEquals("8:00 AM (+3 days)", r.etaTime)
    }

    @Test
    fun timeHelpers() {
        assertNull(Calculator.addHoursToTime(null, 0, false, 1.0))
        assertEquals("12:30 PM", Calculator.addHoursToTime(12, 0, true, 0.5)!!.time)
        assertEquals("12:30 AM", Calculator.addHoursToTime(12, 0, true, 12.5)!!.time)
        assertEquals("0 h 0 m", Calculator.fmtHours(0.0))
        assertTrue(Calculator.fmtHours(Double.POSITIVE_INFINITY) == NO_HOURS)
    }
}
